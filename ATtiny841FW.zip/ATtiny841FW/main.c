/*
main.c - Last modified 30 July 2015

This is an ATTiny841 firmware intended to expose the four 16 bit PWM outputs
through an I2C interface. All registers are also available for read/write.

This library is free software; you can redistribute it and/or
modify it under the terms of the GNU Lesser General Public
License as published by the Free Software Foundation; either
version 2.1 of the License, or (at your option) any later version.

This library is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
Lesser General Public License for more details.

You should have received a copy of the GNU Lesser General Public
License along with this library; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

Written by Ben Rose for TinyCircuits.

The latest version of this library can be found at https://tiny-circuits.com/
*/

#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <avr/sleep.h>

#define FIRMWARE_REVISION_REG 0x19
#define FIRMWARE_REVISION 0x1A

#define true 1
#define false 0

#define TWI_BUFFER_LENGTH 32
#define TWI_ACK   true
#define TWI_NACK  false
#define TWI_COMPLETE true
#define TWI_INCOMPLETE false

int main(void);
void onReceive(volatile uint8_t*, volatile int);
void onRequest();
void setPWM(uint8_t, unsigned int);
unsigned int getUInt(volatile uint8_t *);

volatile uint8_t twi_rxBuffer[TWI_BUFFER_LENGTH];
volatile uint8_t twi_rxBufferIndex;
volatile uint8_t twi_rxBufferIndex;
volatile uint8_t firstByte=false;

//for 16 bit registers, high byte is larger register number. write high byte first, read low byte first
const uint8_t mode_register_inc = 0xAA;
const uint8_t mode_register_dec = 0xAB;
const uint8_t mode_command = 0xAC;

volatile uint8_t mode=0xAC;
volatile uint8_t *currentRegister=0;

volatile uint8_t sleepCommand=false;

volatile unsigned int failsafeValues[4]={0,0,0,0};
volatile unsigned int failsafeTimeout=0;
volatile unsigned int failsafeCounter=0;

int main(void){
  //PA0 and PA3 are used to set least significant address bits
  PUEA=(1<<3)|(1<<0);
  _delay_ms(10);
  uint8_t address=0x62;
  if(PINA&(1<<0))address+=1;
  if(PINA&(1<<3))address+=2;
  PUEA=0;//clear pullup enables after
  
  PUEA=_BV(4)|_BV(6);
  TWSA = address << 1;
  TWSCRA=_BV(TWSHE)|_BV(TWDIE)|_BV(TWASIE)|_BV(TWEN)|_BV(TWSIE);
  TWSCRB=_BV(TWHNM);
  
  //Servo Driver TinyShield
  //S1->PA1->TOCC0->OC1B->TOCC0S0
  //S2->PA2->TOCC1->OC1A->TOCC1S0
  //S3->PA7->TOCC6->OC2B->TOCC6S1
  //S4->PB2->TOCC7->OC2A->TOCC7S1
  
  //Dual Motor Driver TinyShield
  //M1 uses S1 and S2 outputs
  //M2 uses S3 and S4 outputs
  
  sei();
  while(1){
    if(sleepCommand){
      //sleepCommand can only be set after stop bit is detected,
      //but the hardware is still holding the bus if we sleep immediately
      //TWCH bit in TWSSRA should tell us if bus is held, but doesn't seem to help here.
      //Instead, look at the SCL pin state to make sure bus is really released
      //while(TWSSRA & _BV(TWCH));//doesn't seem to work
      while(!(PINA&_BV(4)));
      sleepCommand=false;
      sleep_enable();
      sleep_cpu();
      sleep_disable();
    }
    if(failsafeTimeout){
      if(TIFR0&_BV(TOV0)){
        TIFR0=_BV(TOV0);
        failsafeCounter++;
        if(failsafeCounter>=failsafeTimeout){
          failsafeCounter=0;
          setPWM(1, failsafeValues[0]);
          setPWM(2, failsafeValues[1]);
          setPWM(3, failsafeValues[2]);
          setPWM(4, failsafeValues[3]);
        }
      }
    }
  }
  return 0;
}
//register access mode:
//first data byte sets register, following bytes are written to incrementing registers.

//command mode:
#define COMMAND_SET_MODE 0x00  //write mode- command, register access
#define COMMAND_SERVO_1 0x01 //write 16 bit pwm value 1
#define COMMAND_SERVO_2 0x02 //write 16 bit pwm value 2
#define COMMAND_SERVO_3 0x03 //write 16 bit pwm value 3
#define COMMAND_SERVO_4 0x04 //write 16 bit pwm value 4
#define COMMAND_MOTOR_1 0x05 //write first two 16 bit pwm values
#define COMMAND_MOTOR_2 0x06 //write second two 16 bit pwm values
#define COMMAND_ALL_PWM 0x07 //write four 16 bit pwm values
#define COMMAND_TIMER_1 0x08 //write 16 bit timer 1 top value
#define COMMAND_TIMER_2 0x09 //write 16 bit timer 2 top value
#define COMMAND_PRESCALER_1 0x0A //write timer 1 prescaler
#define COMMAND_PRESCALER_2 0x0B //write timer 2 prescaler
#define COMMAND_CLOCK_PRESCALER 0x0C //write system clock prescaler
#define COMMAND_SET_SLEEP_MODE 0x0D //set sleep mode
#define COMMAND_SLEEP 0x0E //go to sleep after I2C communication is done
#define COMMAND_SET_FAILSAFE_VALUES 0x0F //set failsafe PWM values - default is 0
#define COMMAND_SET_FAILSAFE_PRESCALER 0x10 //set failsafe timeout
#define COMMAND_SET_FAILSAFE_TIMEOUT 0x11 //set failsafe timeout
#define COMMAND_ALL_PWM_8 0x12 //write four 8 bit pwm values

void onReceive(volatile uint8_t* inByte, int numBytes){
  uint8_t command=inByte[0];
  uint8_t i;
  if(command){
    if(mode==mode_register_inc || mode==mode_register_dec){
      currentRegister=(uint8_t *)(uint16_t)command;
      for(i=1;i<numBytes;i++){
        *currentRegister=inByte[i];
        if(mode==mode_register_inc){
          currentRegister++;
       }else{
          currentRegister--;
        }
      }
    }else if(mode==mode_command){
      if(command==COMMAND_MOTOR_1 && numBytes==5){
        setPWM(1, getUInt(inByte+1));
        setPWM(2, getUInt(inByte+3));
      }else if(command==COMMAND_MOTOR_2 && numBytes==5){
        setPWM(3, getUInt(inByte+1));
        setPWM(4, getUInt(inByte+3));
      }else if(command==COMMAND_ALL_PWM && numBytes==9){
        setPWM(1, getUInt(inByte+1));
        setPWM(2, getUInt(inByte+3));
        setPWM(3, getUInt(inByte+5));
        setPWM(4, getUInt(inByte+7));
      }else if(command>=COMMAND_SERVO_1 && command<=COMMAND_SERVO_4){
        if(numBytes==3)
          setPWM(command, getUInt(inByte+1));
      }else if(command==COMMAND_TIMER_1 && numBytes==3){
        ICR1=getUInt(inByte+1)-1;
      }else if(command==COMMAND_TIMER_2 && numBytes==3){
        ICR2=getUInt(inByte+1)-1;
      }else if(command==COMMAND_PRESCALER_1 && numBytes==2){
        TCCR1B=(TCCR1B&0xF8)|(inByte[1]&0x07);
      }else if(command==COMMAND_PRESCALER_2 && numBytes==2){
        TCCR2B=(TCCR2B&0xF8)|(inByte[1]&0x07);
      }else if(command==COMMAND_CLOCK_PRESCALER && numBytes==2){
        uint8_t div=inByte[1]&0x0F;
        cli();
        CCP=0xD8;
        CLKPR=div;
        sei();
      }else if(command==COMMAND_SET_SLEEP_MODE && numBytes==2){
        set_sleep_mode(inByte[1]);
      }else if(command==COMMAND_SLEEP && numBytes==1){
        sleepCommand=true;
      }else if(command==COMMAND_SET_FAILSAFE_VALUES && numBytes==9){
        failsafeValues[0]=getUInt(inByte+1);
        failsafeValues[1]=getUInt(inByte+3);
        failsafeValues[2]=getUInt(inByte+5);
        failsafeValues[3]=getUInt(inByte+7);
      }else if(command==COMMAND_SET_FAILSAFE_PRESCALER && numBytes==2){
        TCCR0B=(TCCR0B&0xF8)|(inByte[1]&0x07);
      }else if(command==COMMAND_SET_FAILSAFE_TIMEOUT && numBytes==3){
        failsafeTimeout=getUInt(inByte+1);
        TCNT0=0;
        TIFR0=_BV(TOV0);
      }else if(command==COMMAND_ALL_PWM_8 && numBytes==5){
        setPWM(1, inByte[1]);
        setPWM(2, inByte[2]);
        setPWM(3, inByte[3]);
        setPWM(4, inByte[4]);
      }
    }
  }else if(command==COMMAND_SET_MODE && numBytes==2){
    if(inByte[1]==mode_register_inc){
      mode=inByte[1];
    }else if(inByte[1]==mode_register_dec){
      mode=inByte[1];
    }else if(inByte[1]==mode_command){
      mode=inByte[1];
    }
  }
}

unsigned int getUInt(volatile uint8_t * intLSB){
  return ((unsigned int)intLSB[1]<<8) | (unsigned int)intLSB[0];
}

void setPWM(uint8_t output, unsigned int pulseWidth){
  failsafeCounter=0;
  if(output==1){
    if(pulseWidth){
      OCR1B=pulseWidth-1;
      TOCPMCOE|=(1<<TOCC0OE);
    }else{
      TOCPMCOE&=~(1<<TOCC0OE);
      OCR1B=0;
    }
  }else if(output==2){
    if(pulseWidth){
      OCR1A=pulseWidth-1;
      TOCPMCOE|=(1<<TOCC1OE);
    }else{
      TOCPMCOE&=~(1<<TOCC1OE);
      OCR1A=0;
    }
  }else if(output==3){
    if(pulseWidth){
      OCR2B=pulseWidth-1;
      TOCPMCOE|=(1<<TOCC6OE);
    }else{
      TOCPMCOE&=~(1<<TOCC6OE);
      OCR2B=0;
    }
  }else if(output==4){
    if(pulseWidth){
      OCR2A=pulseWidth-1;
      TOCPMCOE|=(1<<TOCC7OE);
    }else{
      TOCPMCOE&=~(1<<TOCC7OE);
      OCR2A=0;
    }
  }
}

void twi_reply(uint8_t ack, uint8_t complete)
{
  uint8_t regBuffer=_BV(TWHNM)|_BV(TWCMD1);
  if(!ack)
    regBuffer|=_BV(TWAA);
  if(!complete)
    regBuffer|=_BV(TWCMD0);
  TWSCRB=regBuffer;
}

ISR(TWI_SLAVE_vect)
{
  uint8_t status = TWSSRA;
  if(status & _BV(TWDIF)){ //finished receiving or transmitting data
    if(!(status & _BV(TWDIR))){ //receiving from master, new rx data
      if(twi_rxBufferIndex < TWI_BUFFER_LENGTH){//still room in buffer
        twi_rxBuffer[twi_rxBufferIndex++] = TWSD;
        twi_reply(TWI_ACK,TWI_INCOMPLETE);
      }else{//no room in buffer
        twi_reply(TWI_NACK,TWI_COMPLETE);
      }
    }else{ //sending data to master, finished sending a byte
      if(firstByte || !(status & _BV(TWRA))){ //first byte or master sent ack
        firstByte=false;
        if(currentRegister==(uint8_t *)(uint16_t)FIRMWARE_REVISION_REG){
          TWSD = FIRMWARE_REVISION;
        }else{
          TWSD = *currentRegister;
        }
        if(mode==mode_register_inc){
          currentRegister++;
        }else{
          currentRegister--;
        }
        twi_reply(TWI_ACK,TWI_INCOMPLETE);
      }else{//nack, not first byte
        twi_reply(TWI_NACK,TWI_COMPLETE);//NACK might not make any difference
      }
    }
  }
  if(status & _BV(TWASIF)){ //address or stop flag
    if(status & _BV(TWAS)){  //address received
      twi_reply(TWI_ACK,TWI_INCOMPLETE);//ack address, start of transfer
      firstByte=true;
    }else{ //stop condition
      twi_reply(TWI_ACK,TWI_COMPLETE);
      if(!(status & _BV(TWDIR))){//in slave receiver mode
        if(twi_rxBufferIndex < TWI_BUFFER_LENGTH){
          twi_rxBuffer[twi_rxBufferIndex] = '\0';
        }
        onReceive(twi_rxBuffer, twi_rxBufferIndex);
        twi_rxBufferIndex = 0;
      }
    }
  }
  if(status & (_BV(TWBE)|_BV(TWC))){ //bus error
    twi_reply(TWI_NACK,TWI_COMPLETE);
    TWSSRA|=_BV(TWDIF)|_BV(TWASIF)|_BV(TWC)|_BV(TWBE);
  }
}